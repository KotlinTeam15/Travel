package com.example.travelapp

class Hotel (
    val hotelName : String,
    val hotelAddress: String,
    val hotelDetail : String,
    val hotelImage : String?
)
/*{
  val hotel, hotelJson;
  val hotelUrl
}*/