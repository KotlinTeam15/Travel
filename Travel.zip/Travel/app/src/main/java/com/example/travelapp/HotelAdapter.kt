package com.example.travelapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HotelAdapter(private val hotellists: List<Hotel>) : RecyclerView.Adapter<HotelAdapter.ViewHolder>() {
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        // TODO: Create member variables for any view that will be set
        val hotelTitle: TextView
        val hotelOverview: TextView
        val hotelAddresstv: EditText
        val hotelImage: ImageView

        init {
            // TODO: Store each of the layout's views into
            // the public final member variables created above
            hotelTitle = itemView.findViewById(R.id.hotelTitle)
            hotelOverview = itemView.findViewById(R.id.hotelOverview)
            hotelAddresstv = itemView.findViewById(R.id.hotelAddresstv)
            hotelImage = itemView.findViewById(R.id.hotelImage)
        }

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HotelAdapter.ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val contactView = inflater.inflate(R.layout.hotel_item, parent, false)
        return ViewHolder(contactView)
    }

    // Involves populating data into the item through holder
    override fun onBindViewHolder(viewHolder: HotelAdapter.ViewHolder, position: Int) {
        // Get the data model based on position
        val hotellist = hotellists.get(position)
        // Set item views based on your views and data model
        val hotelTitle = viewHolder.hotelTitle
        hotelTitle.setText(hotellist.hotelName)
        val hotelAddresstv = viewHolder.hotelAddresstv
        hotelAddresstv.setText(hotellist.hotelAddress)
    }

    // Returns the total count of items in the list
    override fun getItemCount(): Int {
        return hotellists.size
    }
}