package com.example.travelapp

class City(
    val cityName: String,
    val countryName: String,
    val imageURL: String?) {
}